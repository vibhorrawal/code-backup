import socket

connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

#taking user input
html = input('Website : ')

connection.connect((html, 80))

handshake = 'GET ' + html + ' HTTP/1.0\r\n\r\n'.encode()

connection.send(handshake)

while True:

    data = connection.recv(512)

    if len(data) < 1:
        break
    
    data = data.decode()

    #sqlite implementation
    #

connection.close()

#parsing with beautiful soup 