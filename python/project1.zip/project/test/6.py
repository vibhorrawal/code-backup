from tkinter import *
from tkinter import PhotoImage

def page1():
	def get_entry():
	    print (ent.get())
	    return 1

	def get_entry2():
		print ('1'+ ent.get()) 
		return 2   
	root = Tk()
	large_font = ('Verdana',30)
	canvas = Canvas(root, width=600, height=600)
	canvas.pack()

	widget = Label(canvas, text='WEB CRAWLER', fg='black')
	widget.config(font=("Courier", 40))
	widget.pack()
	canvas.create_window(300, 230, window=widget)
	var = StringVar(root)
	ent = Entry(root,textvariable = var,font=large_font)
	canvas.create_window(300, 310, window=ent)

	btn = Button(root, text="CREATE DATABASE", command=get_entry,height=2,width=15)
	canvas.create_window(170, 370, window=btn)
	btn2 = Button(root, text="SEARCH", command=get_entry2,height=2,width=15)
	canvas.create_window(400, 370, window=btn2)
	root.mainloop()
