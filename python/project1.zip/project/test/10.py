from tkinter import *
master = Tk()

LINKS=("http://www.python.org", "http://www.heaven.com")
 
def showLink(event):
    idx= int(event.widget.tag_names(CURRENT)[1])
    print (LINKS[idx])

txt=Text(master)
txt.pack(expand=True, fill="both")
txt.insert(END, "Press ")
txt.insert(END, "here ", ('link', str(0)))
txt.insert(END, "for Python. Press ")
txt.insert(END, "here ", ('link', str(1)))
txt.insert(END, "for Heaven.")
txt.tag_config('link', foreground="blue")
txt.tag_bind('link', '<Button-1>', showLink)
 
master.mainloop()
