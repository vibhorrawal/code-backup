from bs4 import BeautifulSoup 
from urllib.request import urlopen
import ssl

def data(string)
	# Ignore SSL certificate errors
	ctx = ssl.create_default_context()
	ctx.check_hostname = False
	ctx.verify_mode = ssl.CERT_NONE
	links = list()
	text =''	
	#string = 'https://python.org'

	try:
		html = urlopen(string, context=ctx).read()
		#print('works')

	except:
		html = urlopen('http://detectportal.firefox.com', context=ctx).read()
		#print('this')

	soup = BeautifulSoup(html, "html.parser")
	a = 0
	#a[][] = None
	#tags
		
	tag_a = soup('a')
	for tag in tag_a:
		# print('TAG:', tag)
		# print('URL:', tag.get('href', None))
		# print('Contents:', tag.contents[0])
		# print('Attrs:', tag.attrs)
		# print('')
		href = tag.get('href',None)
		if 'http' in href :
			links.append(href)
		elif href[0] == '#' or href is None:
			a
		elif href[0] == '/':
			links.append(string + href)
		else:
			links.append(string + '/' + href)	
	# var = '//'
		# for link in links:
		# 	if var in link:
		# 		links.remove(link)

		# for var in links:
		# 	links.pop((links.index('///')))

		# for i in range(len(links)):
		# 	if var in links[i]:
		# 			links[i] = None

		
	text = " ".join(soup.get_text().split())
	# print (links)
	# print('done')
	