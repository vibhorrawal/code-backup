newerlinks = list()
links = [1,2,3]
level = 2
i =0
for l in range(level):
	for link in links:
		# thislink = link
		templinks = [link,link + 1000, link + 2000]

		i = i + 1
		newerlinks = newerlinks + templinks

	links = newerlinks	
	print (links)
