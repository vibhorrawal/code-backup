import six

print(six.page1())