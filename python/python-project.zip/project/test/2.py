import socket

connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

connection.connect(('mnit.ac.in', 80))

handshake = 'GET http://mnit.ac.in HTTP/1.0\r\n\r\n'.encode()

connection.send(handshake)

while True:
    data = connection.recv(512)

    if len(data) < 1:
        break
        
    print(data.decode(),end='')

connection.close()