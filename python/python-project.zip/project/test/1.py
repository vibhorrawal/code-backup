from urllib import request

fhand = request.urlopen('http://mnit.ac.in')

for line in fhand:
	
	line = line.strip()
	#print(line)
	line = line.decode()
	#print(line)
	print(line)